#include <iostream>
using namespace std;
#include "TreeNode.h"
#include <queue>

int height(TreeNode<int> *root) {
    int ans = 0;
    for(int i = 0; i < root -> children.size(); i++) {
        int a = height(root -> children[i]);
        if(a > ans) {
            ans = a;
        }
    }
    return ans + 1;
}

TreeNode<int>* takeInputLevelWise() {
    int rootData;
    cin >> rootData;
    TreeNode<int> *root = new TreeNode<int>(rootData);

    queue<TreeNode<int>*> q;
    
    q.push(root);

    while(!q.empty()) {
        TreeNode<int> *current = q.front();
        q.pop();

        int n;
        cout << "Enter no. of children of " << current-> data << " : " << endl;
        cin >> n;
    
        for(int i = 0; i < n; i++) {
            cout << "Enter " << i << "th child of " << current -> data << " : ";
            int data;
            cin >> data;
            TreeNode<int> *child = new TreeNode<int>(data);
            q.push(child);
            
            // connect current and child ??
            current -> children.push_back(child);
        }
    
    }
    return root;
}
















TreeNode<int>* takeInput() {
    int data;
    
    cout << "Enter root data : ";
    cin >> data;

    TreeNode<int> *root = new TreeNode<int>(data);
    cout << "Enter no. of children : ";
    int n;
    cin >> n;

    for(int i = 0; i < n; i++) {
        TreeNode<int> *child = takeInput();
        root -> children.push_back(child);
    }
    return root;
}

void print(TreeNode<int> *root) {
    cout << root -> data << " : ";
    for(int i = 0; i < root -> children.size(); i++) {
        //cout << root -> chidren[i] -> data << ", ";
        TreeNode<int> *child = root -> children[i];
        cout << child -> data << ", ";
    }
    cout << endl;
    for(int i = 0; i < root -> children.size(); i++) {
        TreeNode<int> *child = root -> children[i];
        print(child);
    }
}





















int main() {
    TreeNode<int> *root = takeInputLevelWise();   
    print(root);
}










