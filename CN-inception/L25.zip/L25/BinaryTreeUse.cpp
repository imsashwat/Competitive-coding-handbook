#include <iostream>
using namespace std;
#include "BinaryTreeNode.h"


int height(BinaryTreeNode<int> *root) {
    if(root == NULL) {
        return 0;
    }
    int leftHeight = height(root -> left);
    int rightHeight = height(root -> right);

    return max(leftHeight, rightHeight) + 1;
}

BinaryTreeNode<int>* takeInput() {
    int data;
    cin >> data;
    if(data == -1) {
        return NULL;
    }
    BinaryTreeNode<int> *root = new BinaryTreeNode<int>(data);

    root -> left = takeInput();
    root -> right = takeInput();

    return root;
}

int main() {
    
}

