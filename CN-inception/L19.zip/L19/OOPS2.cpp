#include <iostream>
using namespace std;

class Student {
    public :
        const int rollNumber;
        int age;
        int &x;

        Student(int r, int age, int x) : rollNumber(r), age(age), x(x) {
        
        }


};

int main() {
    int const a = 10;
    //a = 10;


    //Student s1(101);
}





