#include <string>

class Student {
    public :
        char *name;
        int rollNumber;
        
        //string name2;
       
        Student() {

        }

        // Copy constructor
        // Student &s = Main.s1;
        Student(Student const &s) {
            cout << "Copy constructor called ! " << endl;
            name = new char[strlen(s.name) + 1];
            strcpy(name, s.name);
            
            this -> rollNumber = s.rollNumber;
        
            // s.rollNumber = -1;
        }












        /*
        Student(char *n, int r, string name2) {
            // Shallow copy
            //name = n;
            
            // Deep copy
            this -> name2 = name2;


            // Deep copy
            name = new char[strlen(n) + 1];
            strcpy(name, n);
    

            this -> name = name;


            rollNumber = r;
        }*/
};
