#include <iostream>
using namespace std;
#include "Student.cpp"

int main() {
    Student s1;

    Student s2(s1);



    /*
    char a[] = "abcd";
    Student s1(a, 101);

    a[0] = 'x';
    Student s2(a, 102);

    cout << a << endl;
    cout << s1.name << endl;
    cout << s2.name << endl;
    */
    }

