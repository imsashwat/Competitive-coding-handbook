#include <iostream>
using namespace std;

class Student {
        int rollNumber;
    
    public :
        int age;

        int getRollNumber() const {
            return rollNumber;
        }

        void setRollNumber(int r) const {
            rollNumber = r;
        }

        void print() const {
            cout << rollNumber << " " << age << endl;
        }

};

int main() {
    Student s1;
    s1.print();

    Student const s2 = s1;
    //int const a;

    // s2.setRollNumber(101);
    s2.print();

    s2.setRollNumber(101);







}









