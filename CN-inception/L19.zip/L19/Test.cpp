class Student {
    public :
        int age;
        int rollNumber;

        Student(int age, int r) {
            this -> age = age;
            rollNumber = r;
        }
};

int main() {
    Student s1(20, 101);

    Student s2(s1);

    Student s3(30, 1010);

    s3 = s1;

    Student s4 = s1;    // Student s4(s1);


    // 100
    int *a = new int[4];    // 1,  2, 3, 4
    
    // 200
    int *b = new int[3];    // 6, 7, 8

    a = b;

    cout << a << endl;





















}
