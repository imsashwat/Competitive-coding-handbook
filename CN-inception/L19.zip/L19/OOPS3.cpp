#include <iostream>
using namespace std;

class Student {
    public :
        int age ;
        int rollNumber;
        static int totalStudents;

        static const int x = 200;


        Student() {
            totalStudents++;
        }
};

int Student :: totalStudents = 0;

int main() {
    Student s1;
    s1.age = 20;
    s1.rollNumber = 101;
    
    Student s2, s3, s4, s5;
    
    s2.totalStudents = 51;
    cout << Student :: totalStudents << endl;
    cout << s1.totalStudents << endl;

    Student :: totalStudents = 100;












    //s1.totalStudents = 50;
}

