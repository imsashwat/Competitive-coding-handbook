#include <iostream>
using namespace std;

int length(char input[]) {
    int len = 0;
    for(int i = 0; input[i]; i++) {
        len++;
    }
    return len;
}


int main() {
    char input[100];

    cin >> input;   

    cout << length(input) << endl;

    
    
    
    /*
    // cin >> a;       // Wrong

    cout << a << endl;

    char c[10];
    
    for(int i = 0; i < 3; i++) {
        cin >> c[i];
    }

    
    //cin >> c;   // abcd
    
    
    // c[0] = 'a', c[1] = 'b', c[2] = 'c', c[3] = 'd', c[4] = '\0';
    
    cout << c << endl;

    //c[2] = '\0';
    //cout << c << endl;

    c[4] = 'e';
    cout << c << endl;


    for(int i = 0; i < 10; i++) {
        cout << c[i] << "-";
    }
    cout << endl;
    */



}

