#include <iostream>
using namespace std;
#include "TreeNode.h"

int height(TreeNode<int> *root) {
    int ans = 0;
    for(int i = 0; i < root -> children.size(); i++) {
        int a = height(root -> children[i]);
        if(a > ans) {
            ans = a;
        }
    }
    return ans + 1;
}




TreeNode<int>* takeInput() {
    int data;
    
    cout << "Enter root data : ";
    cin >> data;

    TreeNode<int> *root = new TreeNode<int>(data);
    cout << "Enter no. of children : ";
    int n;
    cin >> n;

    for(int i = 0; i < n; i++) {
        TreeNode<int> *child = takeInput();
        root -> children.push_back(child);
    }
    return root;
}

void print(TreeNode<int> *root) {
    cout << root -> data << " : ";
    for(int i = 0; i < root -> children.size(); i++) {
        //cout << root -> chidren[i] -> data << ", ";
        TreeNode<int> *child = root -> children[i];
        cout << child -> data << ", ";
    }
    cout << endl;
    for(int i = 0; i < root -> children.size(); i++) {
        TreeNode<int> *child = root -> children[i];
        print(child);
    }
}





















int main() {
    TreeNode<int> *root = takeInput();   
    print(root);
}










