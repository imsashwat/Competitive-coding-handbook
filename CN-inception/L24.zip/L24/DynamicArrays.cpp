#include <iostream>
using namespace std;
#include <vector>

int main() {
    vector<int> v;   
    
    // Insert elment : push_back(e)
    for(int i = 0; i < 5; i++) {
        v.push_back(i);
        v[0] = 100;
    }

    v[0] = 100;
    for(int i = 0; i < 5; i++) {
        cout << v[i] << endl;
    }

    v[1] = 100;

    cout << "Size : " << v.size() << endl;
    // Delete elemenets from last : pop_back()
    v.pop_back();

    // Size
    cout << "Size : " << v.size() << endl;


    // Dynamic Allocation

    vector<int> *v2 = new vector<int>;
    
    v2 -> push_back(10);

    // Access ith element
    cout << v2 -> at(0) << endl;


    int *a = new int;
    int *b = new int();














}

