#include <iostream>
using namespace std;

// Find and print the substring from index i to index j
void substring(char input[], int i, int j) {

}

void reverseEachWord(char input[]) {
    // 1. start = 0, end = 0;
    // 2. Run a loop over input string 
        // 3. Run another loop till space or null character
        // 4. Update your end of word
        // 5. Call reverseHelper function
        // 6. Update start of your word
}

int main() {
    
}

