#include <iostream>
using namespace std;


void printArray(int input[][10], int r, int c) {
    for(int i = 0; i < r; i++) {
        for(int j = 0; j < c; j++) {
            // input[i][j] = input[i * C + j]
            cout << input[i][j] << " "; 
        }
        cout << endl;
    }
}

int main() {

    int a1[] = {1, 2, 3};
    int a4[100] = {0};
    
    
    int a2[10] = {1, 2, 3};

    int b1[][2] = {{1, 2}, {3, 4}};
    int b2[][5] = {{1, 2}};

    int b3[10][5] = {{1, 2}, {3, 4}, {5}};

    int b4[2][2] = {0};
    for(int i = 0; i < 2; i++) {
        for(int j = 0; j < 2; j++) {
            cout << b4[i][j] << " ";
        }
        cout << endl;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    int input[10][10];

    int rows, cols;     // rows = 2, cols = 4
    cin >> rows >> cols;

    for(int j = 0; j < rows; j++) {
        for(int i = 0; i < cols; i++) {
            cin >> input[j][i]; 
        }
    }


    for(int j = 0; j < 10; j++) {
        for(int i = 0; i < 10; i++) {
            cout << input[j][i] << " "; 
        }
        cout << endl;
    }
    
    
    /*
    printArray(input, rows, cols);




    for(int j = 0; j < cols; j++) {  //col
        for(int i = 0; i < row; i++) {      // i - row
            cout << input[i][j];    
        }
    }
    */














}

