class Pair {
    int first;
    int second;

    public :

    int getFirst() {
        return first;
    }

    int getSecond() {
        return second;
    }

    void setFirst(int f) {
        first = f;
    }

    void setSecond(int s) {
        second = s;
    }
};


