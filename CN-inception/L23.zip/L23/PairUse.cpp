#include <iostream>
using namespace std;
#include "PairTemplate.h"
#include "Pair.h"

int main() {

    // Creating Triplet using Pair
    PairTemplate<PairTemplate<int, int>, int> p1;

    p1.second = 10;
    PairTemplate<int, int> p2;
    p2.first = 20;
    p2.second = 30;
    p1.first = p2;




    
    /*
    PairTemplate<int, char> p1;
    cout << p1.getFirst() << endl;
    cout << p1.getSecond() << endl;
    */

    /*
    Pair p1;
    PairTemplate<int> p2;

    p2.setFirst(10);
    p2.setSecond(20);

    cout << p2.getFirst() << endl;
    cout << p2.getSecond() << endl;

    PairTemplate<double> p3;
    cout << p3.getFirst() << endl;
    cout << p3.getSecond() << endl;
    
    PairTemplate<char> p4;
    PairTemplate<bool> p5;
    */

}







