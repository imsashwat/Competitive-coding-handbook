template <typename T, typename V>
class PairTemplate {
    public :
    T first;
    V second;


    T getFirst() {
        return first;
    }

    V getSecond() {
        return second;
    }

    void setFirst(T f) {
        first = f;
    }

    void setSecond(V s) {
        second = s;
    }
};



