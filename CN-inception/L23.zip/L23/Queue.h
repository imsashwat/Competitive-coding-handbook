template <typename T>
class Queue {
    T *data;
    int nextIndex;
    int frontIndex;
    int size;           
    int capacity;   // Total size of queue array

    public :
    Queue() {
        data = new T[5];
        nextIndex = 0;
        frontIndex = -1;
        size = 0;
        capacity = 5;
    }

    int getSize() {
        return size;
    }

    bool isEmpty() {
        return size == 0;
    }

    void enqueue(T element) {
        if(size == capacity) {
            // Queue Full
            T *temp = new T[2 * capacity];
            int j = 0;
            for(int i = frontIndex; i < capacity; i++) {
                temp[j++] = data[i];
            }
            for(int i = 0; i < frontIndex; i++) {
                temp[j++] = data[i];
            }
            delete [] data;
            data = temp;
            nextIndex = capacity;
            capacity *= 2;
            frontIndex = 0;
        }
        data[nextIndex] = element;
        nextIndex = (nextIndex + 1) % capacity;
        /*
        nextIndex++;
        if(nextIndex == capacity) {
            nextIndex = 0;
        }*/
        if(size == 0) {
            frontIndex = 0;
        }
        size++;
    }

    T front() {
        if(isEmpty()) {
            cout << "Queue Empty ! " << endl;
            return 0;
        }
        return data[frontIndex];
    }

    T dequeue() {
        if(isEmpty()) {
            cout << "Queue Empty ! " << endl;
            return 0;
        }
        T ans = data[frontIndex];
        frontIndex = (frontIndex + 1) % capacity;
        size--;
        if(size == 0) {
            frontIndex = -1;
            nextIndex = 0;
        }
        return ans;
    }


































};
