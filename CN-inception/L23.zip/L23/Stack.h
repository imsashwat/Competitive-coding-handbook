template <typename T>
class Stack {
    T *data;
    int nextIndex;
    int capacity;

    public :
    Stack() {
        nextIndex = 0;
        data = new T[5];
        capacity = 5;
    }

    int getSize() {
        return nextIndex;
    }

    bool isEmpty() {
        return nextIndex == 0;
    }

    void push(T element) {
        if(nextIndex == capacity) {
            //cout << "Stack full !" << endl;
            //return;
            T *temp = new T[2 * capacity];
            for(int i = 0; i < capacity; i++) {
                temp[i] = data[i];
            }
            delete [] data;
            data = temp;
            capacity *= 2;
        }
        data[nextIndex] = element;
        nextIndex++;
    }

    T top() {
        if(isEmpty()) {
            cout << "Stack Empty ! " << endl;
            return 0;
        }
        return data[nextIndex - 1];
    }

    T pop() {
        if(isEmpty()) {
            cout << "Stack Empty ! " << endl;
            return 0;
        }
        T ans = data[nextIndex - 1];
        nextIndex--;
        return ans;
        

        // OR
        // nextIndex--;
        // return data[nextIndex];
    
    }





































    

};
