class Fraction {
    int numerator;
    int denominator;

    public :
    Fraction(int numerator, int d) {
        this -> numerator = numerator;
        denominator = d;
    }

    void simplify() {
        int gcd = 1;
        int a = min(numerator, denominator);
        for(int i = 1; i < a; i++) {
            if(numerator % i == 0 && denominator % i == 0) {
                gcd = i;
            }
        }
        numerator /= gcd;
        denominator /= gcd;
    }

    /*
    // Fraction f(Main.f2);
    void add(Fraction const &f) {
        int lcm = denominator * f.denominator;
        int x = numerator*(lcm / denominator);
        int y = f.numerator * (lcm / f.denominator);

        numerator = x + y;
        denominator = lcm;
        
        simplify();   
    }*/

    /*
    Fraction add(Fraction const &f) {
        int lcm = denominator * f.denominator;
        int x = numerator*(lcm / denominator);
        int y = f.numerator * (lcm / f.denominator);

        // numerator = x + y;
        // denominator = lcm;
        
        int n = x + y;
        int d = lcm;
        
        Fraction fNew(n, d);

        fNew.simplify();   
    
        return fNew;
    }*/


    Fraction operator+(Fraction const &f) {
        int lcm = denominator * f.denominator;
        int x = numerator*(lcm / denominator);
        int y = f.numerator * (lcm / f.denominator);

        // numerator = x + y;
        // denominator = lcm;
        
        int n = x + y;
        int d = lcm;
        
        Fraction fNew(n, d);

        fNew.simplify();   
    
        return fNew;
    }

    // ==
    bool operator==(Fraction const &f2) {
        return numerator == f2.numerator && 
            denominator == f2.denominator;
    }


    /*
    void operator++() {
        numerator = numerator + denominator;
        simplify();
    }*/




    // Pre-increment
    Fraction& operator++() {
        cout << "this : " << this << endl;
        numerator = numerator + denominator;
        simplify();
    
        // this contains address of f1
        return *this;
    }

    // Post-increment
    const Fraction operator++(int) {
        Fraction fNew(*this);
        numerator = numerator + denominator;
        simplify();
        return fNew;
    }




























    /*
    int fun(int a) {
        a++;
        return a;
    }


    int fun2(int a) {
        int *b = &a;
        return *b;
    }*/




























    void print() const {
        cout << numerator << "/" << denominator << endl;
    }
};












