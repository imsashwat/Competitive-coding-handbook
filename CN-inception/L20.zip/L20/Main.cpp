#include <iostream>
using namespace std;
#include "Fraction.cpp"


int main() {
    int i = 5;
    ++(++i);

    //(i++)++;

    cout << i << endl;
    
    
    Fraction f1(10, 20);
    f1.print();

    Fraction f3 = f1++;

    //(f1++)++;

    Fraction f2 = f1++;

    //int i = 5;
    // int j = i++;


    cout << "After increment : " << endl;
    f1.print();
    f2.print();


    // Fraction f2(4, 5);
    // f2.print();
  

    /*
   //    ++f1;

    //++f1;

    ++(++f1);
    
    // f1 = ++(++f1);  // Copy assignment operator is called
    
     
     cout << "After increment " << endl;
    f1.print();
    */



    /*
    // add(f1, f2);     Invalid - need object to call function
    // f1.add(f1, f2);

    //f1.add(f2);  // Add f1 and f2 and then put result in f1
    //cout << "After addition : " << endl;
    //f1.print();

    Fraction f3 = f1 + f2;
    cout << "After addition : " << endl;
    f3.print();


    if(!(f1 == f2)) {
        cout << "true" << endl;
    
    else {
        cout << "false" << endl;
    }

    */









}












