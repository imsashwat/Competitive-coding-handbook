#include <iostream>
using namespace std;

int returnSubsequences(string input, string output[]) {
    // Base case
    if(input.size() == 0) {
        output[0] = '\0';
        return 1;
    }

    // Rec call
    int s = returnSubsequences(input.substr(1), output);
   
    // Small calc
    for(int i = 0; i < s; i++) {
        output[i+s] = input[0] + output[i];
    }

    return s*2;

}

int main() {
    string input;
    cin >> input;

    string output[10000];
    int size = returnSubsequences(input, output);
    for(int i = 0; i < size; i++) {
        cout << output[i] << endl;
    }
}

