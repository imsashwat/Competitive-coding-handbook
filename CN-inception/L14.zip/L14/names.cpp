#include <iostream>
using namespace std;

int main() {
    // Take string input with space
    /*
    char a1[100];
   
    //cin >> a1;
    cin.getline(a1, 100, 'd');
    
    cout << "a1 : " << a1 << endl;
    */
   
    
    string a2;
    
    // cin >> a2;
    getline(cin, a2, 'd');

    cout << "a2 : " << a2 << endl;
    



































    
    
    /*
    // Using string
    string n1[3] = {"abc", "def", "gh"};

    string names[3];

    for(int i = 0; i < 3; i++) {
        cin >> names[i];
    }
    for(int i = 0; i < 3; i++) {
        cout << names[i] << endl;
    }

    // Using character array
    char b[10];
    cin >> b;
    
    char n3[][100] = {{"ab"}, {"xyz"}};

    char n2[3][100];
    
    
    for(int i = 0; i < 3; i++) {
        cin >> n2[i];
    }
    */




















}

