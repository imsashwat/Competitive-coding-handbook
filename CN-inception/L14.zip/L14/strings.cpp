#include <iostream>
using namespace std;
#include <string>


int main() {
    /*
    char s1[100] = "abcd";

    
    string s2 = "abc";


    // Invalid
    //char s3[10];
    // s3 = "def";

    string s4;
    s4 = "xyz";
    s4 = "ahu";

    s4 = s2;
    cout << s4 << endl;
    s4 = s1;
    cout << s4 << endl;
    */


    /*
    // Dynamic Allocation
    int *a = new int;
    *a = 4;

    string *s6 = new string;    // Dynamic
    string s7;                  // static
    
    s7 = "abc";
    *s6 = "xyz";
    cout << s7 << endl;
    cout << s6 << endl;
    cout << *s6 << endl;
    */

    /*
    // Take input from user
    int a;
    cin >> a;
    char s1[100];
    cin >> s1;
    string s2;
    cin >> s2;
    cout << s2 << endl;

    string *s3 = new string;
    cin >> (*s3);

    s2 = s1;
    */

    /*
    // Use as character array
    string s1 = "abcd";
    cout << s1 << endl;

    s1[0] = 'x';
    cout << s1 << endl;
    */


    /*
    // Inbuilt functions
    string s1 = "cd";
    cout << s1.size() << endl;

    // Substring
    cout << s1.substr(1) << endl;   // starting index = 1
    cout << s1.substr(2) << endl;

    // output is "ab"
    cout << s1.substr(2, 3) << endl;    // starting index = 0, len = 2

    // Find function
    cout << s1.find("cde") << endl;
    */

    /*
    // Operators
    string s1 = "abc";
    string s2 = "def";
    string s3 = s1 + s2 + "xyz";
    cout << s3 << endl;


    int i = 2, j = 3;
    i += j;     // i = i + j


    s1 += s2;   // s1 = s1 + s2;
    */


    // strings array
    string s1[100];
    s1[0] = "abc";
    s1[1] = "def";
    s1[2] = "i";

    cout << s1[0] << endl;
    cout << s1[0][0] << endl;
    //cout << s1.size() << endl;  // invalid
    
    cout << s1[0].size() << endl;










    
    
    string *s2 = new string[100];






















    



































































































}

