#include <iostream>
using namespace std;
#include "Fraction.cpp"


int main() {
    Fraction f1(10, 20);
    f1.print();

    Fraction f2(4, 5);
    f2.print();

    // add(f1, f2);     Invalid - need object to call function
    // f1.add(f1, f2);

    f1.add(f2);  // Add f1 and f2 and then put result in f1
    cout << "After addition : " << endl;
    f1.print();
}












