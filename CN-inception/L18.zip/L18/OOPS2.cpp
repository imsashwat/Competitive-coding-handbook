#include <iostream>
using namespace std;

class Student {
    public :
        int age;
        int rollNumber;

        Student() {

        }
    
        Student(int r) {
            cout << this << endl;
            this -> RollNumber = r;
        }

        
        ~Student() {
            cout << "Destructor" << endl;       
        }

};

int main() {
    Student s1(101);     // Default Constructor
    
    cout << "S1 : " << &s1 << endl;
















    /*
    cout << sizeof(s1) << endl;



    s1.age = 20;
    s1.rollNumber = 101;

    Student s2(102);
    

    Student s3(s1);     // Copy constructor
    
    Student s5 = s1;    // Copy constructor : Student s5(s1);

    Student *s4 = new Student();
    
    Student s6(*s4);
    s2 = *s4;

    *s4 = s1;

    */















   //  delete s4;


    // cout << s4 << endl;

    // cout << &s1 << endl;


}















