#include <iostream>
using namespace std;

class Student {
    int rollNumber;
    
    public :
    int age;
    
    // Default constructor
    Student() {
        cout << "Default Constructor " << endl;    
    }

    // User-defined constructor
    // Parametrized constructor
    Student(int r) {
        cout << "Parametrized constructor" << endl;
        rollNumber = r;
    }

    Student(int r, int a) {
        rollNumber = r;
        age = a;
    }
    
    int getRollNumber() {
        return rollNumber;
    }

    void setRollNumber(int r, int password) {
        if(password != 1234) {
            return;
        }
        if(r < 0) {
            return;
        }
        rollNumber = r;
    }

    void printDetails() {
        cout << "Age : " << age << endl;
        cout << "RollNumber : " << rollNumber << endl;
    }.

};


int main() {
    int a;
    Student s1;     // s1 is an object
    // s1.Student();    // Default constructor
    
    // s2 -> Student();
    // (*s2).Student();
    Student *s2 = new Student;
    Student *s3 = new Student();

    Student s4(101);    // Parameterized constructor will be called
    Student *s5 = new Student(102);





























    /*
    s1.setRollNumber(101, 123);
    cout << s1.getRollNumber() << endl;


    a = 10;

    // age = 20;
    
    s1.age = 20;
    //s1.rollNumber = 101;

    s2.age = 24;
    // s2.rollNumber = 102;

    s1.printDetails();
    s2.printDetails();

    // Dynamic Allocation
    int *b = new int;
    *b = 8;
    Student *s3 = new Student;
    (*s3).age = 10;
    s3 -> age = 8;
    */











}






