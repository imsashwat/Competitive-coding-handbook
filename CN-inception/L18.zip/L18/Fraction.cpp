class Fraction {
    int numerator;
    int denominator;

    public :
    Fraction(int numerator, int d) {
        this -> numerator = numerator;
        denominator = d;
    }

    void simplify() {
        int gcd = 1;
        int a = min(numerator, denominator);
        for(int i = 1; i < a; i++) {
            if(numerator % i == 0 && denominator % i == 0) {
                gcd = i;
            }
        }
        numerator /= gcd;
        denominator /= gcd;
    }

    // Fraction f(Main.f2);
    void add(Fraction f) {
        int lcm = denominator * f.denominator;
        int x = numerator*(lcm / denominator);
        int y = f.numerator * (lcm / f.denominator);

        numerator = x + y;
        denominator = lcm;
        
        simplify();
        
    }









    void print() {
        cout << numerator << "/" << denominator << endl;
    }
};












