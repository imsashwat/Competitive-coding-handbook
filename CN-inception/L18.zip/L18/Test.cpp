#include <iostream>
using namespace std;

void test(int a, int b) {

}

void test(int a) {

}

void test() {

}


int main() {
    test();
    test(1);
    test(2, 3);
}








