#include <iostream>
using namespace std;

int sum(int a, int b) {
    int c = a + b;
    return c;
}

bool checkPrime(int n) {
    bool ans;

    // Statements

    return ans;
}

void print(int n) {
    for(int i = 1; i <= n; i++) {
        if(i == 3) {
            return;
        }
        cout << i << endl;
    }
}

int main() {
 

    print(4);
    
    
    
    int a, b;
    cin >> a >> b;

    int d = sum(a, b);

    cout << d << endl;

    bool t = checkPrime(5);
    cout << t << endl;


}

