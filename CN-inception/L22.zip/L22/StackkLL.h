class StackLL {
    Node *head;
    int size;

    public :

    StackLL() {
    }

    int getSize() {
    }

    bool isEmpty() {
    }

    int top() {
    }

    void push(int element) {
    }

    int pop() {
    }
};
