class Stack {
    int *data;
    int nextIndex;
    int capacity;

    public :
    Stack(int size) {
        nextIndex = 0;
        data = new int[size];
        capacity = size;
    }

    int getSize() {
        return nextIndex;
    }

    bool isEmpty() {
        return nextIndex == 0;
    }

    void push(int element) {
        if(nextIndex == capacity) {
            cout << "Stack full !" << endl;
            return;
        }
        data[nextIndex] = element;
        nextIndex++;
    }

    int top() {
        if(isEmpty()) {
            cout << "Stack Empty ! " << endl;
            return INT_MIN;
        }
        return data[nextIndex - 1];
    }

    int pop() {
        if(isEmpty()) {
            cout << "Stack Empty ! " << endl;
            return INT_MIN;
        }
        int ans = data[nextIndex - 1];
        nextIndex--;
        return ans;
        

        // OR
        // nextIndex--;
        // return data[nextIndex];
    
    }





































    

};
