#include <iostream>
using namespace std;
#include "Node.h"

Node* takeInput_Rec() {
    int data;
    cin >> data;

    // Base case
    if(data == -1) {
        return NULL;
    }

    // Small Calc
    Node *head = new Node(data);
    
    // Recursive call
    head -> next = takeInput_Rec();
    
    return head;
}

// Take LL input from user and return head (i.e. adress of 1st node)
Node* takeInput() {
    int data;
    cin >> data;
    Node *head = NULL, *tail = NULL;  // starting address of LL
    while(data != -1) {
        Node *n = new Node(data);
        if(head == NULL) {
            head = n;
            tail = n;
        }
        else {
            tail -> next = n;
            tail = tail -> next;
            // Connect last node of existing LL to n
            //head -> next = n;      
            /*
            Node *temp = head;
            while(temp -> next != NULL) {
                temp = temp -> next;
            }
            temp -> next = n;
            */

            }   
        cin >> data;
    }
    return head;
}

void print(Node *head) {
    Node *tmep = head;
    while(tmep != NULL) {
        cout << tmep -> data << " ";
        tmep = tmep -> next;
    }
}


int main() {
 
    //Node *head = takeInput();
    
    Node *head = takeInput_Rec();
    print(head);





    
    /*
    // Create a new node
    Node n1(10);
    Node n2(20);
    Node n3(30);
    Node n4(40);
    Node n5(50);

 
    n1.next = &n2;
    n2.next = &n3;
    n3.next = &n4;
    n4.next = &n5;

    Node *head = &n1;

    while(head != NULL) {
        cout << head -> data << " ";
        head = head -> next;
    }
    */



















    //Node *n3 = new Node(30);
    // Node *n4 = new Node(40);

    /*
    // Print Node's value
    cout << n1.data << endl;
    cout << n3 -> data << endl;
    cout << (*n4).data << endl;

    // Connect two nodes
    n1.next = &n2;

    n3 -> next = n4;

    // Print LL
    Node *head = &n1;

    cout << "Print : " << endl;
    cout << head -> data << endl;
    head = head -> next;
    cout << head -> data << endl;
    */

}




























